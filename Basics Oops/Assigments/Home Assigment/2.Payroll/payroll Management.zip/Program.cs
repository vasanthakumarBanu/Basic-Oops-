﻿using System;
using Payroll;
class Program
{
    public static void Main(string[] args)
    {
        Operations.AddingDefaultData();
        Operations.Mainmenu();
    }
}