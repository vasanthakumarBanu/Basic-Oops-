﻿using System;
using Online_Library_Management;
class Program
{
    public static void Main(string[] args)
    {
        Operations.AddingDefaultData();
        Operations.Mainmenu();
    }
}